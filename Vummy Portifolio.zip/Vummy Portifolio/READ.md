Vumilia Mihayo - Portfolio Website

This is a personal portfolio website for Vumilia Mihayo, built with HTML, CSS, and JavaScript. The site showcases projects, contact information, and includes an interactive feedback survey. Designed to be sleek, modern, and mobile-friendly.

Features

Hero Section with dynamic intro and CTA
About Me section with background details
Projects section showcasing real work
Feedback Survey with confirmation popup
Contact Info** for networking
Smooth scroll navigation
Dark mode aesthetic

Tech Stack

HTML5
CSS3
JavaScript 
Google Fonts - Poppins



Folder Structure

├── index.html       # Main HTML file
├── images/          # Images and media
├── styles/          # CSS files
├── scripts/         # JavaScript files
└── README.md        # Project documentation

